# Fritzing_Parts
Fritzing Parts - CNC Shield V3.00

![alt tag](https://github.com/Protoneer/Fritzing_Parts/raw/master/CNCShield-Fritzing.png)
